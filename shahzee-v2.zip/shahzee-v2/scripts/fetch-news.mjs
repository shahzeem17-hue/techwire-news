// SHAHZEE. TECHWIRE — RSS collector. Node 20+, no dependencies.
// Run by GitHub Actions on a schedule; writes data/news.json (static file the website reads).
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';

const OUT = new URL('../data/news.json', import.meta.url);
const KEEP_DAYS = 120, MAX_ITEMS = 400, PER_FEED = 25;
// name, url, extra categories. Feed URLs must be verified: the run log prints OK/FAIL per feed.
const FEEDS = [
  ['OpenAI', 'https://openai.com/news/rss.xml', ['ai', 'tools']],
  ['Google', 'https://blog.google/rss/', []],
  ['Apple Newsroom', 'https://www.apple.com/newsroom/rss-feed.rss', ['apple']],
  ['Samsung Newsroom', 'https://news.samsung.com/global/feed', ['samsung']],
  ['Microsoft', 'https://blogs.microsoft.com/feed/', []],
  ['The Verge', 'https://www.theverge.com/rss/index.xml', []],
  ['TechCrunch', 'https://techcrunch.com/feed/', []],
  ['Ars Technica', 'https://feeds.arstechnica.com/arstechnica/index', []],
  ['Engadget', 'https://www.engadget.com/rss.xml', []],
  ['Android Authority', 'https://www.androidauthority.com/feed/', ['android', 'phones']],
  ['GSMArena', 'https://www.gsmarena.com/rss-news-reviews.php3', ['phones']],
];
const OFFICIAL = new Set(['OpenAI', 'Google', 'Apple Newsroom', 'Samsung Newsroom', 'Microsoft']);
const RULES = [
  ['ai', /\b(ai|artificial intelligence|machine learning|llms?|chatbots?|generative|neural|deep learning)\b/i],
  ['tools', /\b(chatgpt|gpt-?\d\S*|openai|gemini|claude|anthropic|copilot|llama|mistral|deepseek|grok|sora|midjourney|stable diffusion|language models?|ai (model|agent|assistant)s?)\b/i],
  ['phones', /\b(smartphones?|phones?|iphone|galaxy|pixel|oneplus|xiaomi|foldables?|handsets?)\b/i],
  ['apple', /\b(apple|iphone|ipad|macbook|ios|macos|airpods|apple watch|vision pro|siri)\b/i],
  ['android', /\b(android|pixel|one ui|google play)\b/i],
  ['samsung', /\b(samsung|galaxy|one ui|exynos)\b/i],
  ['hardware', /\b(processors?|chips?|chipsets?|cpus?|gpus?|snapdragon|qualcomm|nvidia|amd|intel|tensor|exynos|semiconductors?|ram|ssd|laptops?)\b/i],
  ['security', /\b(security|vulnerabilit\w*|breach\w*|ransomware|malware|cve-\d+|hack\w*|phishing|zero-day|cyber\w*)\b/i],
];

const ent = { '&amp;': '&', '&lt;': '<', '&gt;': '>', '&quot;': '"', '&#39;': "'", '&apos;': "'", '&nbsp;': ' ' };
const unent = s => s.replace(/&(amp|lt|gt|quot|apos|nbsp|#39);/g, m => ent[m]).replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(+n)).replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCodePoint(parseInt(n, 16)));
const unwrap = s => s.replace(/^\s*<!\[CDATA\[([\s\S]*?)\]\]>\s*$/, '$1');
const strip = s => unent(unwrap(s).replace(/<[^>]*>/g, ' ')).replace(/\s+/g, ' ').trim();
const tag = (x, n) => { const m = x.match(new RegExp(`<${n}(?:\\s[^>]*)?>([\\s\\S]*?)</${n}>`, 'i')); return m ? m[1] : ''; };
const attr = (x, n, a, cond = '') => { const m = x.match(new RegExp(`<${n}\\b([^>]*)>`, 'gi')); if (!m) return ''; for (const t of m) { if (cond && !new RegExp(cond, 'i').test(t)) continue; const v = t.match(new RegExp(`\\b${a}=["']([^"']+)["']`, 'i')); if (v) return unent(v[1]); } return ''; };
const httpOnly = u => (/^https?:\/\//i.test(u || '') ? u : '');
const canon = u => { try { const x = new URL(u); x.hash = ''; ['utm_source','utm_medium','utm_campaign','utm_term','utm_content','ref','mibextid'].forEach(k => x.searchParams.delete(k)); return x.href.replace(/\/$/, ''); } catch { return u; } };
const idOf = u => createHash('sha1').update(canon(u)).digest('hex').slice(0, 12);

export function parseFeed(xml, source, extra = []) {
  const blocks = xml.match(/<(item|entry)[\s>][\s\S]*?<\/\1>/gi) || [];
  const out = [];
  for (const b of blocks.slice(0, PER_FEED)) {
    const title = strip(tag(b, 'title'));
    let url = strip(tag(b, 'link')) || attr(b, 'link', 'href', 'rel=["\']alternate["\']') || attr(b, 'link', 'href');
    url = httpOnly(unent(unwrap(url)).trim());
    const rawDate = strip(tag(b, 'pubDate') || tag(b, 'published') || tag(b, 'updated') || tag(b, 'dc:date'));
    const t = Date.parse(rawDate);
    if (!title || !url || isNaN(t) || t > Date.now() + 864e5) continue; // never invent dates
    const body = tag(b, 'description') || tag(b, 'summary') || tag(b, 'content:encoded') || tag(b, 'content');
    let desc = strip(body); if (desc.length > 220) desc = desc.slice(0, 217).replace(/\s+\S*$/, '') + '…';
    const full = unent(unwrap(tag(b, 'content:encoded') || tag(b, 'content') || body));
    const img = httpOnly(attr(b, 'media:thumbnail', 'url') || attr(b, 'media:content', 'url', 'medium=["\']image|\\.(jpe?g|png|webp)') || attr(b, 'enclosure', 'url', 'type=["\']image') || (full.match(/<img[^>]+src=["']([^"']+)["']/i) || [])[1] || '');
    const text = `${title} ${desc}`;
    const cats = [...new Set([...extra, ...RULES.filter(([, re]) => re.test(text)).map(([c]) => c)])];
    if (!cats.includes('tech')) cats.push('tech');
    out.push({ id: idOf(url), title, desc, url, img, src: source, official: OFFICIAL.has(source), cats, date: new Date(t).toISOString() });
  }
  return out;
}

async function main() {
  let old = { items: [] };
  try { old = JSON.parse(await readFile(OUT, 'utf8')); } catch {}
  const map = new Map((old.items || []).map(i => [i.id, i]));
  const status = {}; let added = 0;
  await Promise.all(FEEDS.map(async ([name, url, extra]) => {
    try {
      const r = await fetch(url, { headers: { 'User-Agent': 'SHAHZEE-TechWire/1.0 (personal portfolio RSS reader)', Accept: 'application/rss+xml, application/atom+xml, application/xml, text/xml' }, signal: AbortSignal.timeout(20000) });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      const items = parseFeed(await r.text(), name, extra);
      if (!items.length) throw new Error('no items parsed');
      for (const it of items) if (!map.has(it.id)) { map.set(it.id, { ...it, addedAt: new Date().toISOString() }); added++; }
      status[name] = 'OK ' + items.length; console.log('OK  ', name, items.length);
    } catch (e) { status[name] = 'FAIL ' + e.message; console.log('FAIL', name, e.message); }
  }));
  const cutoff = Date.now() - KEEP_DAYS * 864e5;
  const items = [...map.values()].filter(i => Date.parse(i.date) > cutoff).sort((a, b) => Date.parse(b.date) - Date.parse(a.date)).slice(0, MAX_ITEMS);
  const pruned = map.size - items.length;
  if (!added && !pruned && old.updated) { console.log('No changes.'); return; }
  await writeFile(OUT, JSON.stringify({ updated: new Date().toISOString(), status, items }, null, 1));
  console.log(`Wrote ${items.length} items (+${added} new, -${pruned} pruned)`);
}
if (process.argv[1] && import.meta.url === new URL(process.argv[1], 'file:').href) main();
