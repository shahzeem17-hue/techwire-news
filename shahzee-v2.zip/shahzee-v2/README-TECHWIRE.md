# SHAHZEE. TECHWIRE — setup

How it works
1. `.github/workflows/techwire.yml` runs `scripts/fetch-news.mjs` about every 30 minutes (and via the "Run workflow" button).
2. The script reads each RSS feed once, skips bad dates, removes duplicates (same URL = same id), categorises by keywords, keeps 120 days / 400 items, and writes `data/news.json` only when something changed.
3. The bot commits `data/news.json`; your host (GitHub Pages / Netlify / Cloudflare Pages) redeploys automatically.
4. Visitors only download `data/news.json`. No external news site is contacted from their browser, except publisher thumbnails.
5. Notifications: the first visit just records the current articles (no notifications). Later, any article id not seen before becomes one notification, stored in the visitor's localStorage with read/unread state. No accounts, no browser push.

Deploy
1. Create a GitHub repo, upload the whole folder (including the hidden `.github` folder).
2. Settings → Actions → General → Workflow permissions → "Read and write permissions".
3. Actions tab → "TechWire update" → Run workflow. Open the run log: each feed prints OK or FAIL.
4. Publish the repo with GitHub Pages (Settings → Pages → main branch / root), or connect it to Netlify / Cloudflare Pages.

Notes
- Feed URLs in `scripts/fetch-news.mjs` were NOT verified from here. Replace or remove any that print FAIL. Qualcomm is not included because I have no verified feed URL.
- Only title, ~220-character excerpt, link, thumbnail URL, publisher and date are stored. Full articles are never copied.
- GitHub may pause scheduled workflows in repos with no activity for 60 days; re-enable them in the Actions tab.
- Not built: AI summaries, browser push notifications, contact form, PWA.
